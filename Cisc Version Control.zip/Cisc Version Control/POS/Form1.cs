﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\17187\Documents\POS.mdf;Integrated Security=True;Connect Timeout=30");

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Opens connection
            con.Open();
            // SQL command to cheak user name 
            SqlCommand Login_UserName_Check = new SqlCommand("Select UserName from UserDetails where USerName = '"+txtUserName.Text+"'", con);
            // SQL command to validate information
            SqlDataReader NameCheaker = Login_UserName_Check.ExecuteReader();

            // Reader is validating information using if function 
            if(NameCheaker.Read() ==  true)
            {
                // To close the reader
                NameCheaker.Close();
                //closes connection
                con .Close();

                

                con.Open();
                SqlCommand Login_Password_Check = new SqlCommand("Select Password from UserDetails where UserName ='"+txtUserName.Text+"'and Password = '"+txtPassword.Text+"'", con);
                SqlDataReader Password_Reader = Login_Password_Check.ExecuteReader();
                if(Password_Reader.Read() == true) 
                {
                    Password_Reader.Close();
                    con.Close();

                    this.Hide();
                    Work_Station work_Station = new Work_Station();
                    work_Station.Show();
                }
                else
                {
                    Password_Reader.Close();
                    con.Close();

                    txtPassword.Text = "";

                    MessageBox.Show("Wrong Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // To close the reader
                NameCheaker.Close();
                //closes connection
                con.Close();

                txtUserName.Text = ""; 

                MessageBox.Show("Username not available","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }
            
            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
