﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS
{
    public partial class Stock : Form
    {
        string ItemCount;

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\17187\Documents\POS.mdf;Integrated Security=True;Connect Timeout=30");

        public Stock()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Stock_Load(object sender, EventArgs e)
        {
            StockOpen();
        }

        //Custom Class to count stocks
        private void StockOpen() 
        { 
            con.Open();
            SqlCommand CountItem = new SqlCommand("Select Count(ItemCode) from Stock",con);
            string ItemCount = CountItem.ExecuteScalar().ToString();

            SqlCommand SumStockValue = new SqlCommand("Select Sum(Prch_Value) from Stock", con);
            string StockValue = SumStockValue.ExecuteScalar().ToString();

            cmbSupplier.Items.Clear();

            SqlCommand SupplierName = new SqlCommand("Select distinct[Supplier] from [Stock]", con);
            SupplierName.ExecuteNonQuery();
            SqlDataReader SupplierReader = SupplierName.ExecuteReader();
            while (SupplierReader.Read()) 
            {
                cmbSupplier.Items.Add(SupplierReader["Supplier"].ToString());
            }
            SupplierReader.Close();

            con.Close();
            
            lblStockCount.Text = ItemCount;
            lblStockValue.Text = "$ " + StockValue;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnPurchasingSummery_Click(object sender, EventArgs e)
        {
            Purchasing_Summery purchasing_Summery = new Purchasing_Summery();
            purchasing_Summery.Show();
        }

        private void fToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stock_View stock_View = new Stock_View();
            stock_View.Show();
        }

        private void removeItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource == null)
            {
                MessageBox.Show("No data avaliable","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else 
            {
                con.Open();
                SqlCommand CountItem = new SqlCommand("Select Count(ItemCOde) from Stock", con);
                ItemCount = CountItem.ExecuteScalar().ToString();
                con.Close();

                if (String.IsNullOrEmpty(ItemCount)) 
                { 
                    ItemCount = "0";
                }

                int StockItem = Convert.ToInt32(ItemCount);

                if (StockItem > 0)
                {
                    //sting value to get row index
                    string RowIndex = dataGridView1.SelectedRows[0].Index.ToString();

                    //convert string value to integer to count the rows available in the datagrid
                    int Row_Index = Convert.ToInt32(RowIndex);

                    DialogResult Confirmation = MessageBox.Show("Are you sure you want this Item", "Item Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (Confirmation == DialogResult.Yes)
                    {
                        //this code line select the row and fetch the row_index
                        DataGridViewRow row = this.dataGridView1.Rows[Row_Index];

                        //declare string variable to get the data from the data table with previous row index
                        string Delete_Item_Code = row.Cells["ItemCode"].Value.ToString();

                        //open connection
                        con.Open();

                        //code to remove item
                        SqlCommand RemoveItem = new SqlCommand("Delete from stock where [ItemCode] = '" + Delete_Item_Code + "'", con);
                        RemoveItem.ExecuteNonQuery();

                        //code to select all items
                        SqlCommand AllItems = new SqlCommand("Select * from [Stock]", con);
                        AllItems.ExecuteNonQuery();
                        SqlDataAdapter ItemAdapter = new SqlDataAdapter(AllItems);
                        DataTable ItemTable = new DataTable();
                        ItemAdapter.Fill(ItemTable);
                        dataGridView1.DataSource = ItemTable;
                        this.dataGridView1.Sort(this.dataGridView1.Columns["ItemCode"], ListSortDirection.Ascending);
                        con.Close();

                        StockOpen();
                    }
                }
                else
                {
                    MessageBox.Show("No Items available in the stock", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
   
            }   
        }

        private void lowStockValueReminderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Low_Stock_Value_Reminder low_Stock_Value_Reminder = new Low_Stock_Value_Reminder();
            low_Stock_Value_Reminder.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txrPurchasingQuantity_TextChanged(object sender, EventArgs e)
        {
            //Only numbers allowed code
            if(string.IsNullOrEmpty(txtPurchasingQuantity.Text)) 
            {
                //line gets cleared
                txtPurchasingQuantity.Text = " ";
                txtPurchasingPrice.Text = " ";
            }
            else
            {
                float qty;
                if (float.TryParse(txtPurchasingQuantity.Text,out qty))
                {

                }
                else
                {
                    //line gets cleared
                    txtPurchasingQuantity.Text = " ";
                    txtPurchasingPrice.Text = " ";
                }
            }
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPurchasingPrice_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPurchasingPrice.Text))
            {
                //line gets cleared
                txtPurchasingPrice.Text = " ";
                txtPurchaseValue.Text = " ";

            }
            else
            {
                float PurchasingPrice;
                if (float.TryParse(txtPurchasingPrice.Text, out PurchasingPrice))
                {
                    //purchasing value = quantity *  purchase price

                    double Purchasing_Value = Convert.ToDouble(txtPurchasingQuantity.Text) * Convert.ToDouble(txtPurchasingPrice.Text);

                    txtPurchaseValue.Text = Convert.ToString(Purchasing_Value);
                }
                else
                {
                    //line gets cleared
                    txtPurchasingPrice.Text = " ";
                    txtPurchaseValue.Text = " ";
                }
            }
        }

        private void txtPurchaseValue_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPurchaseValue.Text))
            {
                //line gets cleared
                txtPurchaseValue.Text = " ";
            }
            else
            {
                float PurchasingValue;
                if (float.TryParse(txtPurchaseValue.Text, out PurchasingValue))
                {

                }
                else
                {
                    //line gets cleared
                    txtPurchaseValue.Text = " ";
                }
            }
        }

        private void txtMRP_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMRP.Text))
            {
                //line gets cleared
                txtMRP.Text = " ";
            }
            else
            {
                float qty;
                if (float.TryParse(txtMRP.Text, out qty))
                {
                    
                }
                else
                {
                    //line gets cleared
                    txtMRP.Text = " ";
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAdditem_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtItemCode.Text))
            {
                MessageBox.Show("Item Code can't be null","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                //When the item code is empty the cursor will automatically move to Item Code text box
                txtItemCode.Focus();
                this.ActiveControl = txtItemCode;
            }
            else
            {
                if (string.IsNullOrEmpty(txtDescription.Text))
                {
                    MessageBox.Show("Description can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //When the description is empty the cursor will automatically move to description text box
                    txtDescription.Focus();
                    this.ActiveControl = txtDescription;
                }
                else 
                {
                    if (string.IsNullOrEmpty(txtPurchasingQuantity.Text))
                    {
                        MessageBox.Show("Purchasing Quantity can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //When the quantitty is empty the cursor will automatically move to quantity text box
                        txtPurchasingQuantity.Focus();
                        this.ActiveControl = txtPurchasingQuantity;
                    }
                    else 
                    {
                        if (string.IsNullOrEmpty(txtPurchasingPrice.Text))
                        {
                            MessageBox.Show("Purchasing Price can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //When the price is empty the cursor will automatically move to price text box
                            txtPurchasingPrice.Focus();
                            this.ActiveControl = txtPurchasingPrice;
                        }
                        else 
                        {
                            if (string.IsNullOrEmpty(txtMRP.Text))
                            {
                                MessageBox.Show("MRP can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                //When the mrp is empty the cursor will automatically move to mrp text box
                                txtMRP.Focus();
                                this.ActiveControl = txtMRP;
                            }
                            else 
                            {
                                if (string.IsNullOrEmpty(txtPurchasingOrderNo.Text))
                                {
                                    MessageBox.Show("Purchase Order Number can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    //When the order number is empty the cursor will automatically move to order number text box
                                    txtPurchasingOrderNo.Focus();
                                    this.ActiveControl = txtPurchasingOrderNo;
                                }
                                else
                                {
                                    if (string.IsNullOrEmpty(cmbSupplier.Text))
                                    {
                                        MessageBox.Show("Supplier can't be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        //When the supplier is empty the cursor will automatically move to supplier text box
                                        cmbSupplier.Focus();
                                        this.ActiveControl = cmbSupplier;
                                    }
                                    else
                                    {
                                        if (Convert.ToDouble(txtMRP.Text) < Convert.ToDouble(txtPurchasingPrice.Text))
                                        {
                                            MessageBox.Show("The selling price can't be less than purchasing price", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            txtMRP.Text = " ";
                                        }
                                        else
                                        {
                                            con.Open();
                                            SqlCommand StockUpdate = new SqlCommand("Insert into Stock([ItemCode],[Description],[Prch_Qty],[Prch_Price],[Prch_Value],[MRP],[Supplier]) values ('" + txtItemCode.Text + "', '" + txtDescription.Text + "', '" + Convert.ToDouble(txtPurchasingQuantity.Text) + "', '" + Convert.ToDouble(txtPurchasingPrice.Text) + "', '" + Convert.ToDouble(txtPurchaseValue.Text) + "', '" + Convert.ToDouble(txtMRP.Text) + "', '" + cmbSupplier.Text + "')", con);
                                            StockUpdate.ExecuteNonQuery();

                                            SqlCommand ViewAllItems = new SqlCommand("Select * from [Stock]", con);
                                            ViewAllItems.ExecuteNonQuery();
                                            SqlDataAdapter ItemAdapter = new SqlDataAdapter(ViewAllItems);//need adapter to load data
                                            DataTable StockTable = new DataTable();//create data table 
                                            ItemAdapter.Fill(StockTable);//Binding the table with adapter
                                            dataGridView1.DataSource = StockTable;//biding the table with datadridview

                                            con.Close();

                                            StockOpen();

                                            txtItemCode.Text = "";
                                            txtDescription.Text = "";
                                            txtPurchasingQuantity.Text = "";
                                            txtPurchasingPrice.Text = "";
                                            txtPurchaseValue.Text = "";
                                            txtMRP.Text = "";
                                            txtPurchasingOrderNo.Text = "";
                                            cmbSupplier.Text = "";
                                        } 
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnViewStock_Click(object sender, EventArgs e)
        {
            con.Open();//open connection
            SqlCommand ViewAllItems = new SqlCommand("Select * from [Stock]", con);
            ViewAllItems.ExecuteNonQuery();
            SqlDataAdapter ItemAdapter = new SqlDataAdapter(ViewAllItems);//need adapter to load data
            DataTable StockTable = new DataTable();//create data table 
            ItemAdapter.Fill(StockTable);//Binding the table with adapter
            dataGridView1.DataSource = StockTable;//biding the table with datadridview
            
            con.Close();//close connection

        }
    }
}
