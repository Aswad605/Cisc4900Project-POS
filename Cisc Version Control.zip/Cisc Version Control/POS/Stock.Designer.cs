﻿namespace POS
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClearEntries = new System.Windows.Forms.Button();
            this.btnAdditem = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbSupplier = new System.Windows.Forms.ComboBox();
            this.txtPurchasingOrderNo = new System.Windows.Forms.TextBox();
            this.txtMRP = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPurchaseValue = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPurchasingPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPurchasingQuantity = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.removeItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowStockValueReminderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewLowStockItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblStockCount = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblStockValue = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnPurchasingSummery = new System.Windows.Forms.Button();
            this.btnPrintStock = new System.Windows.Forms.Button();
            this.btnViewStock = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.btnClearEntries);
            this.panel1.Controls.Add(this.btnAdditem);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.cmbSupplier);
            this.panel1.Controls.Add(this.txtPurchasingOrderNo);
            this.panel1.Controls.Add(this.txtMRP);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtPurchaseValue);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtPurchasingPrice);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtPurchasingQuantity);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtDescription);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtItemCode);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(397, 734);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnClearEntries
            // 
            this.btnClearEntries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClearEntries.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearEntries.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearEntries.ForeColor = System.Drawing.Color.White;
            this.btnClearEntries.Image = global::POS.Properties.Resources.clean;
            this.btnClearEntries.Location = new System.Drawing.Point(217, 662);
            this.btnClearEntries.Name = "btnClearEntries";
            this.btnClearEntries.Size = new System.Drawing.Size(160, 58);
            this.btnClearEntries.TabIndex = 10;
            this.btnClearEntries.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClearEntries.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClearEntries.UseVisualStyleBackColor = false;
            // 
            // btnAdditem
            // 
            this.btnAdditem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAdditem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdditem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdditem.ForeColor = System.Drawing.Color.White;
            this.btnAdditem.Image = global::POS.Properties.Resources.add_item;
            this.btnAdditem.Location = new System.Drawing.Point(22, 662);
            this.btnAdditem.Name = "btnAdditem";
            this.btnAdditem.Size = new System.Drawing.Size(189, 58);
            this.btnAdditem.TabIndex = 9;
            this.btnAdditem.Text = "Add Item";
            this.btnAdditem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdditem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdditem.UseVisualStyleBackColor = false;
            this.btnAdditem.Click += new System.EventHandler(this.btnAdditem_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 578);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 25);
            this.label8.TabIndex = 12;
            this.label8.Text = "Supplier:";
            // 
            // cmbSupplier
            // 
            this.cmbSupplier.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSupplier.FormattingEnabled = true;
            this.cmbSupplier.Location = new System.Drawing.Point(22, 614);
            this.cmbSupplier.Name = "cmbSupplier";
            this.cmbSupplier.Size = new System.Drawing.Size(355, 37);
            this.cmbSupplier.TabIndex = 8;
            // 
            // txtPurchasingOrderNo
            // 
            this.txtPurchasingOrderNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPurchasingOrderNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchasingOrderNo.Location = new System.Drawing.Point(22, 533);
            this.txtPurchasingOrderNo.Multiline = true;
            this.txtPurchasingOrderNo.Name = "txtPurchasingOrderNo";
            this.txtPurchasingOrderNo.Size = new System.Drawing.Size(355, 42);
            this.txtPurchasingOrderNo.TabIndex = 7;
            this.txtPurchasingOrderNo.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // txtMRP
            // 
            this.txtMRP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMRP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMRP.Location = new System.Drawing.Point(22, 452);
            this.txtMRP.Multiline = true;
            this.txtMRP.Name = "txtMRP";
            this.txtMRP.Size = new System.Drawing.Size(355, 42);
            this.txtMRP.TabIndex = 6;
            this.txtMRP.TextChanged += new System.EventHandler(this.txtMRP_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 497);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(245, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Purchasing Order Number:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 416);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(185, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "MRP / Selling Price:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtPurchaseValue
            // 
            this.txtPurchaseValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPurchaseValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchaseValue.Location = new System.Drawing.Point(22, 371);
            this.txtPurchaseValue.Multiline = true;
            this.txtPurchaseValue.Name = "txtPurchaseValue";
            this.txtPurchaseValue.ReadOnly = true;
            this.txtPurchaseValue.Size = new System.Drawing.Size(355, 42);
            this.txtPurchaseValue.TabIndex = 5;
            this.txtPurchaseValue.TextChanged += new System.EventHandler(this.txtPurchaseValue_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 335);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Purchase Value:";
            // 
            // txtPurchasingPrice
            // 
            this.txtPurchasingPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPurchasingPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchasingPrice.Location = new System.Drawing.Point(22, 290);
            this.txtPurchasingPrice.Multiline = true;
            this.txtPurchasingPrice.Name = "txtPurchasingPrice";
            this.txtPurchasingPrice.Size = new System.Drawing.Size(355, 42);
            this.txtPurchasingPrice.TabIndex = 4;
            this.txtPurchasingPrice.TextChanged += new System.EventHandler(this.txtPurchasingPrice_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Purchasing Price:";
            // 
            // txtPurchasingQuantity
            // 
            this.txtPurchasingQuantity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPurchasingQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchasingQuantity.Location = new System.Drawing.Point(22, 209);
            this.txtPurchasingQuantity.Multiline = true;
            this.txtPurchasingQuantity.Name = "txtPurchasingQuantity";
            this.txtPurchasingQuantity.Size = new System.Drawing.Size(355, 42);
            this.txtPurchasingQuantity.TabIndex = 3;
            this.txtPurchasingQuantity.TextChanged += new System.EventHandler(this.txrPurchasingQuantity_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Purchasing Quantity:";
            // 
            // txtDescription
            // 
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(22, 128);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(355, 42);
            this.txtDescription.TabIndex = 2;
            this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Description:";
            // 
            // txtItemCode
            // 
            this.txtItemCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(22, 47);
            this.txtItemCode.Multiline = true;
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(355, 42);
            this.txtItemCode.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item Code:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.Location = new System.Drawing.Point(415, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1227, 603);
            this.dataGridView1.TabIndex = 14;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.removeItemToolStripMenuItem,
            this.fToolStripMenuItem,
            this.lowStockValueReminderToolStripMenuItem,
            this.viewLowStockItemsToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(292, 132);
            // 
            // removeItemToolStripMenuItem
            // 
            this.removeItemToolStripMenuItem.BackColor = System.Drawing.Color.Red;
            this.removeItemToolStripMenuItem.Name = "removeItemToolStripMenuItem";
            this.removeItemToolStripMenuItem.Size = new System.Drawing.Size(291, 32);
            this.removeItemToolStripMenuItem.Text = "Remove Item";
            this.removeItemToolStripMenuItem.Click += new System.EventHandler(this.removeItemToolStripMenuItem_Click);
            // 
            // fToolStripMenuItem
            // 
            this.fToolStripMenuItem.Name = "fToolStripMenuItem";
            this.fToolStripMenuItem.Size = new System.Drawing.Size(291, 32);
            this.fToolStripMenuItem.Text = "Stock Full Screen View ";
            this.fToolStripMenuItem.Click += new System.EventHandler(this.fToolStripMenuItem_Click);
            // 
            // lowStockValueReminderToolStripMenuItem
            // 
            this.lowStockValueReminderToolStripMenuItem.Name = "lowStockValueReminderToolStripMenuItem";
            this.lowStockValueReminderToolStripMenuItem.Size = new System.Drawing.Size(291, 32);
            this.lowStockValueReminderToolStripMenuItem.Text = "Low Stock Value Reminder";
            this.lowStockValueReminderToolStripMenuItem.Click += new System.EventHandler(this.lowStockValueReminderToolStripMenuItem_Click);
            // 
            // viewLowStockItemsToolStripMenuItem
            // 
            this.viewLowStockItemsToolStripMenuItem.Name = "viewLowStockItemsToolStripMenuItem";
            this.viewLowStockItemsToolStripMenuItem.Size = new System.Drawing.Size(291, 32);
            this.viewLowStockItemsToolStripMenuItem.Text = "View Low Stock Items ";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.lblStockCount);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(929, 626);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(358, 120);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lblStockCount
            // 
            this.lblStockCount.AutoSize = true;
            this.lblStockCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockCount.Location = new System.Drawing.Point(13, 70);
            this.lblStockCount.Name = "lblStockCount";
            this.lblStockCount.Size = new System.Drawing.Size(49, 36);
            this.lblStockCount.TabIndex = 1;
            this.lblStockCount.Text = "00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(212, 29);
            this.label9.TabIndex = 0;
            this.label9.Text = "Stock Items Count:";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.lblStockValue);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(1293, 626);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(349, 120);
            this.panel3.TabIndex = 6;
            // 
            // lblStockValue
            // 
            this.lblStockValue.AutoSize = true;
            this.lblStockValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockValue.Location = new System.Drawing.Point(13, 70);
            this.lblStockValue.Name = "lblStockValue";
            this.lblStockValue.Size = new System.Drawing.Size(116, 36);
            this.lblStockValue.TabIndex = 1;
            this.lblStockValue.Text = "$ 00.00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(146, 29);
            this.label12.TabIndex = 0;
            this.label12.Text = "Stock Value:";
            // 
            // btnPurchasingSummery
            // 
            this.btnPurchasingSummery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPurchasingSummery.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnPurchasingSummery.FlatAppearance.BorderSize = 0;
            this.btnPurchasingSummery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchasingSummery.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchasingSummery.ForeColor = System.Drawing.Color.White;
            this.btnPurchasingSummery.Image = global::POS.Properties.Resources.summary_check;
            this.btnPurchasingSummery.Location = new System.Drawing.Point(698, 621);
            this.btnPurchasingSummery.Name = "btnPurchasingSummery";
            this.btnPurchasingSummery.Size = new System.Drawing.Size(146, 125);
            this.btnPurchasingSummery.TabIndex = 13;
            this.btnPurchasingSummery.Text = "Purchasing Summery";
            this.btnPurchasingSummery.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPurchasingSummery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPurchasingSummery.UseVisualStyleBackColor = false;
            this.btnPurchasingSummery.Click += new System.EventHandler(this.btnPurchasingSummery_Click);
            // 
            // btnPrintStock
            // 
            this.btnPrintStock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrintStock.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnPrintStock.FlatAppearance.BorderSize = 0;
            this.btnPrintStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintStock.ForeColor = System.Drawing.Color.White;
            this.btnPrintStock.Image = global::POS.Properties.Resources.printer;
            this.btnPrintStock.Location = new System.Drawing.Point(561, 621);
            this.btnPrintStock.Name = "btnPrintStock";
            this.btnPrintStock.Size = new System.Drawing.Size(131, 125);
            this.btnPrintStock.TabIndex = 12;
            this.btnPrintStock.Text = "Print Stock Balance";
            this.btnPrintStock.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrintStock.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPrintStock.UseVisualStyleBackColor = false;
            // 
            // btnViewStock
            // 
            this.btnViewStock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnViewStock.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnViewStock.FlatAppearance.BorderSize = 0;
            this.btnViewStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStock.ForeColor = System.Drawing.Color.White;
            this.btnViewStock.Image = global::POS.Properties.Resources.report;
            this.btnViewStock.Location = new System.Drawing.Point(415, 621);
            this.btnViewStock.Name = "btnViewStock";
            this.btnViewStock.Size = new System.Drawing.Size(140, 125);
            this.btnViewStock.TabIndex = 11;
            this.btnViewStock.Text = "View All Items";
            this.btnViewStock.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnViewStock.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnViewStock.UseVisualStyleBackColor = false;
            this.btnViewStock.Click += new System.EventHandler(this.btnViewStock_Click);
            // 
            // Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1654, 773);
            this.Controls.Add(this.btnPurchasingSummery);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnPrintStock);
            this.Controls.Add(this.btnViewStock);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(1676, 829);
            this.Name = "Stock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stock";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Stock_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPurchaseValue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPurchasingPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPurchasingQuantity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPurchasingOrderNo;
        private System.Windows.Forms.TextBox txtMRP;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbSupplier;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAdditem;
        private System.Windows.Forms.Button btnClearEntries;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnViewStock;
        private System.Windows.Forms.Button btnPrintStock;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem removeItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblStockCount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblStockValue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnPurchasingSummery;
        private System.Windows.Forms.ToolStripMenuItem lowStockValueReminderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewLowStockItemsToolStripMenuItem;
    }
}